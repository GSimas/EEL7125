This folder holds an example adjusted model and associated result files when running RRA, CMC 
using this specific adjusted model.
The result files and model should be considered as an example of model adjustments that meet 
suggested guidelines as described in 
https://simtk-confluence.stanford.edu/display/OpenSim/Getting+Started+with+RRA#GettingStartedwithRRA-BestPracticesandTroubleshooting. Do not expect your RRA results to match exactly with these reference files.
